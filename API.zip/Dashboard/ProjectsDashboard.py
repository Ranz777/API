import requests
from config import token
import json
import csv
def project_display():
    base_url = 'https://us.app.kirasystems.com/platform-api/v1/projects'
    headers = {'Content-Type': 'application/json', 'Accept': 'application/octet-stream','Authorization': token}
    payload = {'fields' : 'project_id'}
    payload_json = json.dumps(payload)
    r = requests.get(base_url, headers = headers, params = payload_json)
    projects = r.json()
    project_formatted = []
    headers = ['Project ID','Project Name','Client No.','Matter No.','No. of Documents','No. of Users','Users','User Roles','Created Time','Last Updated Time','Link']
    f = open('Dashboard-Project-Details.csv','w')
    w = csv.writer(f)
    w.writerow(headers)
    for pid in projects[-30:]:
        pid = pid['project_id']
        headers = {'Content-Type': 'application/json', 'Accept': 'application/octet-stream','Authorization': token}
        payload = {'fields' : ['creation_time', 'last_update_time','user_id','project_id','client_info','project_info','project_name']}
        payload_json = json.dumps(payload)
        base_url = 'https://us.app.kirasystems.com/platform-api/v1/projects/'+str(pid)
        r = requests.get(base_url, headers = headers,params = payload_json)
        name = r.json()['project_name']
        ct = r.json()['creation_time']
        lut = r.json()['last_update_time']
        cn = str(r.json()['client_info'])
        mn = str(r.json()['project_info'])
        base_url = base_url + '/documents'
        r = requests.get(base_url, headers = headers)
        docs = len(r.json())
        base_url = 'https://us.app.kirasystems.com/platform-api/v1/projects/'+str(pid)+'/users'
        r = requests.get(base_url, headers = headers)
        users = r.json()
        no_of_users = len(r.json())
        user_name = []
        user_role = []
        for item in users:
            user_name.append(item['email'])
            user_role.append(item['role_name'])
        link = ('<a href="/project-details-' +str(pid)+ '">See project details</a>')
        w.writerow([pid,name,cn,mn,docs,no_of_users,user_name,user_role,ct,lut,link])
    return()
