from flask import Flask, render_template
from pandas import *
from ProjectsDashboard import project_display
app = Flask(__name__)
x = project_display()
df = pandas.read_csv('Dashboard-Project-Details.csv')
df2 = df.fillna('')
table1 = df2.loc[:,['Project ID','Project Name','Client No.','Matter No.','Created Time','Last Updated Time','Link']]
table2 = df2.loc[:,['Project ID','Project Name','No. of Documents','No. of Users','Users','User Roles']]
y = table1.to_html(escape=False)
@app.route('/', methods=["GET"])
def display():
    return(render_template('index.html',table = y))
@app.route('/project-details-<project_id>', methods=["GET"])
def display1(project_id):
    project_row = table2['Project ID'] == int(project_id)
    data = table2[project_row]
    users = data.iat[0,4].strip('[').strip(']').replace('\'','').replace(' ','').split(',')
    user_roles = data.iat[0,5].strip('[').strip(']').replace('\'','').replace(' ','').split(',')
    user_table = pandas.DataFrame([users,user_roles]).transpose()
    user_table.columns = ['User','Role']
    user_table = user_table.to_html(escape = False)
    return(render_template('index-2.html', docs= data.iat[0,2],name = data.iat[0,1],users = data.iat[0,3], users_table = user_table))
if __name__=='__main__':
    app.run(host='0.0.0.0',port=80)
