import requests
import csv
import os
import datetime
from config import token
from tkinter import *
import re
base_url = 'https://us.app.kirasystems.com/platform-api/v1/documents/'
params = {'fields':['document_id','document_name']}
headers = {'Accept':'application/json','Authorization':token}
r = requests.get(base_url,headers = headers, params = params)
new_docs = r.json()
number_of_docs = len(new_docs)
counter = 1
while number_of_docs == 10000:
    params = {'fields':['document_id','document_name'],'start':len(new_docs)}
    r = requests.get(base_url,headers = headers, params = params)
    additional_docs = r.json()
    new_docs = new_docs + additional_docs
    number_of_docs = len(additional_docs)

number_of_docs = len(new_docs)
docs_new = {}
for row in new_docs:
        docs_new[row['document_id']] = re.sub('[^ a-zA-Z0-9.&!@#$%^&*()]','',row['document_name'])
docs_old = {}
if  not os.path.isfile('./Docs.csv'):
        csv_file = open('./Docs.csv',"w",newline='')
        row = [datetime.datetime.now().strftime("%Y-%m-%d"),datetime.datetime.now().strftime("%H:%M:%S")]
        writer = csv.writer(csv_file, delimiter=',')
        writer.writerow(row)
        csv_file.close()
with open('./Docs.csv','r') as csv_file:
    reader = list(csv.reader(csv_file))
    old_time = reader[0][1]
    old_date = reader[0][0]
    for row in reader[1:]:
        docs_old[int(row[0])] = row[1]
deleted_docs = []
added_docs = []
for key in docs_old:
    if key not in docs_new:
        deleted_docs.append(docs_old[key])
for key in docs_new:
    if key not in docs_old:
        added_docs.append(docs_new[key])

def overwrite():
    with open('./Docs.csv',"w",newline='') as csv_file:
        writer = csv.writer(csv_file, delimiter=',')
        row = [datetime.datetime.now().strftime("%Y-%m-%d"),datetime.datetime.now().strftime("%H:%M:%S")]
        writer.writerow(row)
        for item in new_docs:
            row = [item['document_id'],item['document_name']]
            writer.writerow(row)
added_docs_stringed = ''
for item in added_docs:
    added_docs_stringed = added_docs_stringed + str(item) + '\n'
deleted_docs_stringed = ''
for item in deleted_docs:
    deleted_docs_stringed = deleted_docs_stringed + str(item) + '\n'
root = Tk()
root.title("Kira Document Inventory Check")
root.geometry("800x1000")
Label1 = Label(root, text = "The document inventory was last checked at: " +str(old_time) + ' on ' + str(old_date), font=("Helvetica",24))
Label1.pack()
LabelDoc = Label(root, text = "There are currently " + str(number_of_docs) + ' documents in your Kira instance.' )
LabelDoc.pack()
Label2 = Label(root, text = "The documents added since then are: ", font=("Helvetica",20))
Label2.pack()
if not added_docs:
    Label3 = Label(root, text = 'None')
else:
    Label3 = Label(root,text = added_docs_stringed)
Label3.pack()
Label4 = Label(root, text = "The documents deleted since then are: ", font=("Helvetica",20))
Label4.pack()
if not deleted_docs:
    Label5 = Label(root, text = 'None')
else:
    Label5 = Label(root, text = deleted_docs_stringed)
Label5.pack()
overwrite()
qbutton = Button(root, text = "Quit", command = lambda: root.destroy())
qbutton.pack(side = BOTTOM)
root.mainloop()



