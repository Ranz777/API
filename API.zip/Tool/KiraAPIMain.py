import os
from tkinter import *
def create():
    os.system("python3 ./ProjectCreate.py")
def create2():
    os.system("python3 ./ProjectExport.py")
def create3():
    os.system("python3 ./DocDelete.py")
root = Tk()
root.title("Kira API Tool")
root.geometry("300x500")
path = './logo.gif'
img = PhotoImage(file=path)
panel = Label(root, image=img) 
panel.pack()
title = Label(root, text = "Kira API Tool")
title.pack()
button1 = Button(root, text="Create a Project", command=create)
button2 = Button(root, text="Export all documents",command=create2)
button3 = Button(root, text = "Check document inventory", command=create3)
button1.pack()
button2.pack()
button3.pack()
qbutton = Button(root, text = "Quit", command = lambda: root.destroy())
qbutton.pack(side = BOTTOM) 
root.mainloop()



