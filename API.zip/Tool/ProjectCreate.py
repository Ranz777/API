import requests
import pprint
import json
import time 
import os
from tkinter import *
from tkinter import filedialog
import subprocess
from config import token
base_url = 'https://us.app.kirasystems.com/platform-api/v1/'
#Get all users
users = {}
url_addition='users?'
headers = {'Content-Type':'application/octet-stream','Accept':'application/octet-stream','Authorization': token}
payload = {'fields':['user_id','full_name']}
r = requests.get(base_url+url_addition, headers = headers, data = payload)
users_json = r.json()
for user in users_json:
    users[user['full_name']] = user['user_id']
sorted_users=sorted(list(users.keys()), key=lambda s: s.lower())
def user_list_generate(sorted_users,permission):
    def callback():
        root.destroy()
        return()
    root = Tk()
    root.title("Kira Project Creator")
    S = Scrollbar(root)
    T = Text(root)#, height=100, width=62)
    S.pack(side=RIGHT, fill=Y)
    T.pack(side=LEFT, fill=Y)
    S.config(command=T.yview)
    T.config(yscrollcommand=S.set)
    T.insert(END, "Select the users who will be " + str(permission) + ", then click 'Submit'")
    for i in range(0,len(sorted_users)):
        exec("CheckVar%d = IntVar()" % (i))
        exec("C%d = Checkbutton(root, text = sorted_users[i], variable = CheckVar%d,onvalue = 1, offvalue = 0, height=5, width = 20)" % (i,i))
        exec("T.window_create(\"end\",window=C%d)" % (i))
    button = Button(root, text="Submit",width=10,command=callback)
    T.insert("end",'\n')
    T.window_create("end",window=button)
    mainloop()
    users_to_add=[]
    for i in range(0,len(sorted_users)):
        val = eval("CheckVar%d.get()" % (i))
        if val == 1:
            users_to_add.append(users[sorted_users[i]])
    return users_to_add
def field_list_generate(sorted_fields):
    root = Tk()
    root.title("Kira Project Creator")
    S = Scrollbar(root)
    T = Text(root, height=100, width=62)
    S.pack(side=RIGHT, fill=Y)
    T.pack(side=LEFT, fill=Y)
    S.config(command=T.yview)
    T.config(yscrollcommand=S.set)
    T.insert(END, "Select the users who will be " + str(permission) + ", then close the window")
    for i in range(0,len(sorted_users)):
        exec("CheckVar%d = IntVar()" % (i))
        exec("C%d = Checkbutton(root, text = sorted_users[i], variable = CheckVar%d,onvalue = 1, offvalue = 0, height=5, width = 20)" % (i,i))
        exec("T.window_create(\"end\",window=C%d)" % (i))
    mainloop()
    users_to_add=[]
    for i in range(0,len(sorted_users)):
        val = eval("CheckVar%d.get()" % (i))
        if val == 1:
            users_to_add.append(users[sorted_users[i]])
    return users_to_add

def callback():
    project = e1.get()
    client = e2.get() 
    matter = e3.get()
    template = e4.get()
    callback.x=[project,client,matter,template]
    top.destroy()
    return()
## Creating a project
url_addition = 'projects'
top = Tk()
top.title("Kira Project Creator")
label1=Label(top, text = "Project Name:")
label2=Label(top, text = "Client No.:")
label3=Label(top, text = "Matter No.:")
label4=Label(top, text = "Default Template Name:")
label1.grid(row = 0, column = 0)
label2.grid(row = 1, column = 0)
label3.grid(row = 2, column = 0)
label4.grid(row = 3, column = 0)
e1 = Entry(top)
e2 = Entry(top)
e3 = Entry(top)
e4 = Entry(top)
e1.grid(row = 0, column=1)
e2.grid(row = 1, column = 1)
e3.grid(row = 2, column = 1)
e4.grid(row = 3, column = 1)
button = Button(top, text="Submit",width=10,command=callback)
button.grid(row=4, column=1)
top.mainloop()
vals=callback.x
headers = {'Content-Type':'application/json','Accept':'application/octet-stream','Authorization': token}
payload = {}
payload['project_name']=vals[0]
payload['client_info']=vals[1]
payload['project_info']=vals[2]
if vals[3] != '':
    payload['default_template_name'] = vals[3]
payload_json=json.dumps(payload)
r=requests.post(base_url+url_addition,headers=headers,data=payload_json)
project_ID = r.json()['project_id']
url_addition = 'projects/' + str(project_ID) + '/users?'
headers = {'Content-Type':'application/json','Accept':'application/octet-stream','Authorization': token}
users_names = {y:x for x,y in users.items()}
y = user_list_generate(sorted_users,'owners')
if y != ['']:
    for user in y:
        payload = {'user_id':int(user),'role_name':'owner'}
        r = requests.put(base_url+url_addition,headers = headers, params = payload)
y = user_list_generate(sorted_users,'members')
if y != ['']:
    for user in y:
        payload = {'user_id':int(user),'role_name':'member'}
        r = requests.put(base_url+url_addition,headers = headers, params = payload)
y = user_list_generate(sorted_users,'read-only')
if y != ['']:
    for user in y:
        payload = {'user_id':int(user),'role_name':'read-only'}
        r = requests.put(base_url+url_addition,headers = headers, params = payload)
fields = {}
url_addition='fields?is_custom=false'
headers = {'Accept':'application/json','Authorization': token}
r = requests.get(base_url+url_addition, headers = headers)
fields_json = r.json()
for field in fields_json:
    fields[field['field_name']]=field['field_id']

sorted_fields=sorted(list(fields.keys()), key=lambda s: s.lower())
def callback():
    root.destroy()
    return()
fields_to_add=[]
root = Tk()
root.title("Kira Project creator")
S = Scrollbar(root)
T = Text(root, height=100, width=65)
S.pack(side=RIGHT, fill=Y)
T.pack(side=LEFT, fill=Y)
S.config(command=T.yview)
T.config(yscrollcommand=S.set)
T.insert(END, "Select the fields you want in your project, then click 'Submit'. \n Title, Parties, and Date are added automatically.")
for i in range(0,len(sorted_fields)):
    exec("CheckVar%d = IntVar()" % (i))
    exec("C%d = Checkbutton(root, text = sorted_fields[i], variable = CheckVar%d,onvalue = 1, offvalue = 0, height=5, width = 20)" % (i,i))
    exec("T.window_create(\"end\",window=C%d)" % (i))
button = Button(root, text="Submit",width=10,command=callback)
T.window_create("end",window=button)
mainloop()
for i in range(0,len(sorted_fields)):
    val = eval("CheckVar%d.get()" % (i))
    if val == 1:
        fields_to_add.append(fields[sorted_fields[i]])
url_addition = 'projects/' + str(project_ID) + '/templates' 
headers = {'Accept':'application/json','Authorization': token}
r = requests.get(base_url+url_addition, headers = headers)
default_template_ID = r.json()[0]['template_id']
url_addition = 'templates/' + str(default_template_ID) + '/fields'
payload={}
headers = {'Content-Type': 'application/json', 'Accept': 'application/octet-stream', 'Authorization': token}
fields_to_remove = [4,5,6,9]
payload['remove_ids'] = fields_to_remove
payload_json = json.dumps(payload)
r = requests.put(base_url + url_addition, headers = headers, data = payload_json)
payload = {}
payload['add_ids'] = sorted(fields_to_add)
payload_json=json.dumps(payload)
r = requests.put(base_url+url_addition,headers = headers, data = payload_json)
root = Tk()
root.withdraw()
root.update()
filename =  filedialog.askdirectory(initialdir = "/",title = "Select file location")
root.update()
list_of_docs = os.listdir(filename)
base_url = 'https://us.app.kirasystems.com/platform-api/v1/documents'
headers = {'Authorization': token}
for f in list_of_docs:
    open_file = open(filename + '/' + f,'rb')
    files = {'file' : (f,open_file,'application/octet-stream')}
    r = requests.post(base_url,headers = headers, files = files, data = {"project_id" : project_ID})
    open_file.close()


