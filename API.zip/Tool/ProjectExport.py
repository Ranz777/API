import requests
import json
import time
from tkinter import *
from tkinter import filedialog
from config import token
counter = 0
def update_status(window, message):
    global counter
    exec("s%d = StringVar()" % (counter))
    exec("x%d = Label(window,textvariable = s%d)" % (counter,counter))
    exec("x%d.pack()" % (counter))
    exec("s%d.set(message)" % (counter))
    window.update()
    counter = counter + 1
def export(format):
    project_id = e1.get()
    if format == 'excel':
        location = str(choose_location.x)+'/download.xls'
        payload = {'export_format':'excel','project_id':project_id} 
        export_type = 'Excel'
    elif format == 'pdf':
        location = str(choose_location.x)+'/download.zip'
        payload = {'export_format':'pdf','project_id':project_id} 
        export_type = 'PDF'
    elif format == 'word':
        location = str(choose_location.x)+'/download.docx'
        payload = {'export_format':'word','project_id':project_id} 
        export_type = 'Word'
    d='{}'
    root.destroy()
    stat = Tk()
    stat.geometry("500x800")
    stat.title("Export Status")
    base_url = 'https://us.app.kirasystems.com/platform-api/v1/documents/export'
    headers = {'Content-Type': 'application/json', 'Accept': 'application/octet-stream','Authorization': token}
    r = requests.post(base_url,headers = headers,data=d,params=payload)
    update_status(stat,"Initiating Excel export")
    job_status = r.headers['Content-Location']
    headers = {'Accept': 'application/json','Authorization': token}
    update_status(stat, export_type + " export in progress")
    retry_counter = 1
    r.status_code = 200
    while r.status_code == 200:
        r = requests.get(job_status,headers = headers)
        try:
            wait_time = r.json()['retry_after']
            update_status(stat, export_type + " export in progress, trying again in 15 seconds")
            retry_counter = retry_counter + 1
        except KeyError:
            continue
        time.sleep(wait_time)
    update_status(stat,export_type + " export generated")
    download_link = r.json()['redirect_href']
    headers = {'Accept': 'application/octet-stream','Authorization': token}
    r = requests.get(download_link,headers = headers)
    file_link = download_link+'/'+str(r.json()[0]['file_id'])
    r = requests.get(file_link,headers = headers)
    update_status(stat,"Downloading " + export_type + " export")
    with open(location, 'wb') as fd:
        for chunk in r.iter_content(chunk_size=128):
            fd.write(chunk)
    update_status(stat,"Export complete")
    quit_button = Button(stat,text = "Quit", command = lambda: stat.destroy())
    quit_button.pack()
    stat.update()
    stat.mainloop()
def choose_location():
    choose_location.x = filedialog.askdirectory(initialdir = "/",title = "Select export directory")
    file_loc.set("Chosen download location: " + str(choose_location.x))
    root.update()
root = Tk()
root.geometry("700x500")
label1=Label(root, text = "Project ID:")
label1.pack()
e1 = Entry(root)
e1.pack()
button_directory = Button(root, text = "Choose Download Location", command = choose_location)
button1 = Button(root, text="Create Excel Export",command= lambda: export('excel'))
button2 = Button(root, text="Create Word Export",command = lambda: export('word'))
button3 = Button(root, text="Create PDF Export",command = lambda: export('pdf'))
file_loc = StringVar()
file_loc.set("Chosen download location: ")
file_loc_label = Label(root,textvariable = file_loc)
button_directory.pack()
file_loc_label.pack()
button1.pack()
button2.pack()
button3.pack()
root.mainloop()
